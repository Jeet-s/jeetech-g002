import { useState } from "react";
import { HomeScreen } from "./screens/HomeScreen";
import { LevelsScreen } from "./screens/LevelsScreen";
import { GameScreen } from "./screens/GameScreen";
import { LEVELS } from "./game/levels";
import { isWon } from "./game/engine";
import { store } from "./modules/store";

/**
 * Screenshot mode: the factory opens the app with <scheme>://shot/<id> on an
 * emulator and captures the screen for the Play Store listing. Every scene
 * renders a REAL state of Flow Forge through the real screens — a solved or
 * nearly-solved board in the steel-and-teal workshop, the win summary, and the
 * level map with progress. Ads are off here.
 */
const noop = () => {};

/** Fully routed board (every fluid connected) — the genre's hero shot. */
const solved = (n: number) => ({ rot: LEVELS[n - 1].solution.slice() });
/** One pipe left to turn — shows flowing fluid next to a visible grey gap. */
const almost = (n: number) => {
  const l = LEVELS[n - 1];
  const r = l.solution.slice();
  // A pipe ON the route (turning a decoy would leave the board solved).
  const onRoute = l.rotatable.filter((k) => {
    const t = r.slice();
    t[k] = (t[k] + 1) % 4;
    return !isWon(l, t);
  });
  const i = onRoute[Math.floor(onRoute.length / 2)];
  if (i != null) r[i] = (r[i] + 1) % 4;
  return { rot: r };
};

export function ScreenshotScene({ id }: { id: string }) {
  // A player mid-campaign: wrenches earned, coins banked, tutorial behind them.
  useState(() => {
    const stars: Record<string, number> = {};
    LEVELS.slice(0, 22).forEach((l, i) => (stars[l.id] = i % 3 === 0 ? 2 : 3));
    store.set({ level: 23, coins: 2480, stars, tutorialDone: true });
    return true;
  });
  const game = (level: number, demo: { rot?: number[]; win?: boolean }) => (
    <GameScreen levelNumber={level} onExit={noop} onSettings={noop} onNextLevel={noop} demo={demo} />
  );
  switch (id) {
    case "solve":
      return game(6, almost(6)); // Workshop — teaches rotate-to-connect
    case "two":
      return game(21, almost(21)); // Color Lab — two fluids braided over two overpasses
    case "hard":
      return game(29, solved(29)); // Refinery — three fluids fully routed
    case "win":
      return game(30, { ...solved(30), win: true }); // Refinery finale — win summary
    case "map":
      return <LevelsScreen onPlay={noop} onBack={noop} />;
    case "home":
    default:
      return <HomeScreen onPlay={noop} onLevels={noop} onShop={noop} onSettings={noop} />;
  }
}
