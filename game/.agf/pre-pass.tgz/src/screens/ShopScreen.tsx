import { useEffect, useRef, useState } from "react";
import { Platform, StyleSheet, Text, View } from "react-native";
import Animated, { FadeIn, FadeOut } from "react-native-reanimated";
import { GameButton, Popup, feedback, fonts, palette } from "../ui";
import { iap, type ShopItem } from "../modules/iap";
import { ads } from "../modules/ads";
import { store } from "../modules/store";

const IOS = Platform.OS === "ios";
const ICON: Record<string, string> = { remove_ads: "🚫", coins_small: "🪙", coins_large: "💰" };
/** Coin sink: a fixed, known bundle of hints (no randomness). */
const HINT_PACK = { hints: 3, coins: 150 };

/** Shop: Remove Ads, coin packs, free coins via rewarded ad, restore purchases. */
export function ShopScreen({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [state, setState] = useState(store.get());
  const [items, setItems] = useState<ShopItem[]>(iap.items());
  // Every shop action ends in a visible result line (bought, restored, unavailable...).
  const [note, setNote] = useState<{ text: string; good: boolean; k: number } | null>(null);
  const noteTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const say = (text: string, good: boolean) => {
    feedback(good ? "success" : "error", good ? "success" : "error");
    setNote((n) => ({ text, good, k: (n?.k ?? 0) + 1 }));
    if (noteTimer.current) clearTimeout(noteTimer.current);
    noteTimer.current = setTimeout(() => setNote(null), 3200);
  };
  useEffect(() => () => { if (noteTimer.current) clearTimeout(noteTimer.current); }, []);
  useEffect(() => store.subscribe(setState), []);
  useEffect(() => {
    if (!visible) { setNote(null); return; }
    setItems(iap.items());
    if (IOS) iap.refresh().then(setItems).catch(() => {});
  }, [visible]);
  // iOS: only products StoreKit returned, at StoreKit's prices — never a placeholder row.
  const list = IOS ? items : items.length ? items : [
    { sku: "remove_ads", title: "Remove Ads", price: "Buy" },
    { sku: "coins_small", title: "Pile of Coins", price: "Buy" },
    { sku: "coins_large", title: "Chest of Coins", price: "Buy" },
  ];
  return (
    <Popup visible={visible} title="Shop" onClose={onClose}>
      <Text style={styles.balance}>🪙 {state.coins.toLocaleString()}</Text>
      {list.filter((i) => !(i.sku === "remove_ads" && state.adsRemoved)).map((i) => (
        <View key={i.sku} style={styles.row}>
          <Text style={styles.icon}>{ICON[i.sku] ?? "✨"}</Text>
          <Text style={styles.title}>{i.title}</Text>
          <GameButton size="sm" variant={i.sku === "remove_ads" ? "accent" : "primary"} label={i.price} onPress={() => {
            iap.purchase(i.sku).then((ok) => {
              if (!ok) say("The store isn't reachable right now. Check your connection and try again.", false);
            });
          }} />
        </View>
      ))}
      {IOS && !items.length ? <Text style={styles.policy}>The App Store is unavailable right now. Please try again later.</Text> : null}
      <View style={styles.row}>
        <Text style={styles.icon}>💡</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{HINT_PACK.hints} Hints</Text>
          <Text style={styles.sub}>You have {state.hints ?? 0} · each shows the pipe to turn</Text>
        </View>
        <GameButton
          size="sm" variant="primary" label={`🪙 ${HINT_PACK.coins}`}
          onPress={() => {
            const s = store.get();
            if (s.coins < HINT_PACK.coins) { say(`You need ${HINT_PACK.coins - s.coins} more coins. Clear levels to earn them.`, false); return; }
            store.set({ coins: s.coins - HINT_PACK.coins, hints: (s.hints ?? 0) + HINT_PACK.hints });
            say(`+${HINT_PACK.hints} hints! You now have ${(s.hints ?? 0) + HINT_PACK.hints}.`, true);
          }}
        />
      </View>
      <View style={styles.row}>
        <Text style={styles.icon}>🎬</Text>
        <Text style={styles.title}>Free 50 coins</Text>
        <GameButton
          size="sm" variant="secondary" label="Watch"
          onPress={() => {
            const shown = ads.showRewarded(() => {
              store.set({ coins: store.get().coins + 50 });
              say("+50 coins added!", true);
            });
            if (!shown) say("No video is ready right now. Try again in a minute.", false);
          }}
        />
      </View>
      {note ? (
        <Animated.View key={note.k} entering={FadeIn.duration(140)} exiting={FadeOut.duration(220)} style={[styles.note, note.good ? styles.noteGood : styles.noteBad]}>
          <Text style={styles.noteText}>{note.text}</Text>
        </Animated.View>
      ) : null}
      <GameButton
        style={{ marginTop: 8 }} size="sm" variant="light" label="Restore purchases"
        onPress={() => {
          iap.restore(true).then((owned) => {
            if (owned == null) say("The store isn't reachable right now. Check your connection and try again.", false);
            else say(owned ? "Purchases restored. Ads are removed." : "No previous purchases found to restore.", owned);
          });
        }}
      />
      <Text style={styles.policy}>No forced ads early on. Remove Ads is one tap, one time, forever — every pack stays fully playable offline.</Text>
      <GameButton style={{ marginTop: 12 }} label="Close" onPress={onClose} />
    </Popup>
  );
}

const styles = StyleSheet.create({
  balance: { fontFamily: fonts.display, fontSize: 24, color: palette.coin, textAlign: "center", marginBottom: 12 },
  row: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: palette.surfaceAlt, borderRadius: 18, padding: 10, marginBottom: 10 },
  icon: { fontSize: 30 },
  title: { flex: 1, fontFamily: fonts.body, fontSize: 17, color: palette.ink },
  sub: { fontFamily: fonts.bodyRegular, fontSize: 12, color: palette.inkSoft, marginTop: 1 },
  note: { borderRadius: 14, paddingVertical: 10, paddingHorizontal: 12, marginBottom: 6, borderWidth: 1.5 },
  noteGood: { backgroundColor: "rgba(40,110,70,0.35)", borderColor: palette.success },
  noteBad: { backgroundColor: "rgba(120,30,30,0.35)", borderColor: palette.danger },
  noteText: { fontFamily: fonts.body, fontSize: 14, lineHeight: 19, color: palette.ink, textAlign: "center" },
  policy: { fontFamily: fonts.bodyRegular, fontSize: 12, color: palette.inkSoft, textAlign: "center", marginTop: 12, lineHeight: 17, paddingHorizontal: 4 },
});
